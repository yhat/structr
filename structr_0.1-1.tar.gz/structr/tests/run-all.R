library(testthat)
library(structr)

test_package("structr")
