library(testthat)
library(foldr)

test_package("foldr")